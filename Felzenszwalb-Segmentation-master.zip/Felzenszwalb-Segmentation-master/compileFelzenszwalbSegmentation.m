% Compile mex functions
%

mex -O segmentFelzenszwalb.cpp -o segmentFelzenszwalb